﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class AssnServiceRequestPropSnapshotTemp
{
    public long ServiceRequestId { get; set; }

    public int PropSnapshotId { get; set; }
}
