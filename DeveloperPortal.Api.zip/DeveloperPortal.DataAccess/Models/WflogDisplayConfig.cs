﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class WflogDisplayConfig
{
    public int Id { get; set; }

    public int WfdefinitionId { get; set; }

    public string Name { get; set; } = null!;

    public string LogGroupedBy { get; set; } = null!;

    public virtual ICollection<ControlViewMaster> ControlViewMasters { get; set; } = new List<ControlViewMaster>();

    public virtual WfDefinition Wfdefinition { get; set; } = null!;
}
