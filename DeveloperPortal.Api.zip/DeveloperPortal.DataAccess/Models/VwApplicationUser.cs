﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class VwApplicationUser
{
    public int ApplicationId { get; set; }

    public int UserId { get; set; }
}
