﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class LutRasubCategory
{
    public int LutRasubCategoryId { get; set; }

    public int LutRacategoryId { get; set; }

    public string RasubCategory { get; set; } = null!;

    public bool? IsAbsolute { get; set; }

    public bool? IsDeleted { get; set; }

    public int? ViewOrder { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedOn { get; set; }

    public virtual LutRacategory LutRacategory { get; set; } = null!;

    public virtual ICollection<QrreasonableAccommodation> QrreasonableAccommodations { get; set; } = new List<QrreasonableAccommodation>();

    public virtual ICollection<ReasonableAccommodation> ReasonableAccommodations { get; set; } = new List<ReasonableAccommodation>();
}
