﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class AssnPropertyUser1
{
    public int PropertyIdentifierId { get; set; }

    public string Idmuser { get; set; } = null!;
}
