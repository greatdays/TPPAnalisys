﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class AssnScopeViolation
{
    public int AssnScopeViolationId { get; set; }

    public int AssnBidScopeOfWorkId { get; set; }

    public int? ViolationId { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedOn { get; set; }

    public virtual AssnBidScopeOfWork AssnBidScopeOfWork { get; set; } = null!;

    public virtual Violation? Violation { get; set; }

    public virtual ICollection<DrawRequest> DrawRequests { get; set; } = new List<DrawRequest>();
}
