﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class AssnOrganizationContact
{
    public int AssnOrganizationContactId { get; set; }

    public int OrganizationId { get; set; }

    public int ContactIdentifierId { get; set; }

    public string AssociationType { get; set; } = null!;

    public DateTime AssociatedFrom { get; set; }

    public DateTime? AssociatedTo { get; set; }

    public bool IsReviewRequired { get; set; }

    public string? Source { get; set; }

    public string? Status { get; set; }

    public bool IsDeleted { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedOn { get; set; }

    public virtual ContactIdentifier ContactIdentifier { get; set; } = null!;

    public virtual Organization Organization { get; set; } = null!;
}
