﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class TempPrefHouseId
{
    public string? Apn { get; set; }

    public string? PrefHouseId { get; set; }
}
