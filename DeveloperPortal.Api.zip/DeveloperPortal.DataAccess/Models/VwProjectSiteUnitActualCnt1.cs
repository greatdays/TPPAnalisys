﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class VwProjectSiteUnitActualCnt1
{
    public int ProjectSiteId { get; set; }

    public int? TotalActualAccessibleUnits { get; set; }

    public int? TotalActualMobilityUnits { get; set; }

    public int? TotalActualSensoryUnits { get; set; }

    public int? TotalActualBothMobilityHvunit { get; set; }
}
