﻿using System;
using System.Collections.Generic;

namespace DeveloperPortal.DataAccess;

public partial class Replacementapn
{
    public string? Hims { get; set; }

    public int? LutSiteCd { get; set; }

    public long? Apnid { get; set; }

    public long? Newapnid { get; set; }
}
