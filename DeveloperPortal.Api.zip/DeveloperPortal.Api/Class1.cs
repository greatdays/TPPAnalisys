﻿namespace DeveloperPortal.Api
{
    public class Class1
    {

    }
}